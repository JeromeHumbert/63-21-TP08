import java.util.Objects;

/*
* Cette classe est censée être abstraite car il ne fait pas sens d'avoir une
* instance de véhicule. Véhicule est concept qui n'est pas matérialisable
* dans la vraie vie. Vu que vous n'avez pas encore vu les classes abstraites,
* nous laisserons la possiblité de création d'instance mais il ne faut pas le
* faire !
*  */
public class Vehicule {
    
}
