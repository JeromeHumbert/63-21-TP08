public class Moto {

}
